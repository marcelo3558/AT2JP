import React, { useState, useEffect } from 'react';
import { Text, View, TextInput, Image, StyleSheet, Button } from 'react-native';
import Constants from 'expo-constants';
import axios from 'axios';

const App = () => {
  const [pokemonId, setPokemonId] = useState(1);
  const [pokemon, setPokemon] = useState(null);

  const fetchPokemon = async () => {
    try {
      const response = await axios.get(
        `https://pokeapi.co/api/v2/pokemon/${pokemonId}`
      );
      setPokemon(response.data);
    } catch (error) {
      console.error(error);
      setPokemon(null);
    }
  };

  useEffect(() => {
    if (pokemonId) {
      fetchPokemon();
    }
  });

  return (
    <View style={styles.container}>
      <View style={styles.pokemonBox}>
      {pokemon ? (
        <Image
        resizeMode="stretch"
        source={{
          uri: pokemon.sprites.other['official-artwork'].front_default,
        }}
        style={styles.pokemonImg}
      />
      ) : (
        <Text style={{ color: 'red' }}>Digite um ID válido</Text>
      )}
      </View>
      {pokemon?(
        <View style={styles.pokemonText}>
        <Text style={styles.pokemonNome}>Nome: {pokemon.name}</Text>
          <Text style={styles.pokemonPeso}>Peso: {pokemon.weight} kg</Text>
          <Text style={styles.pokemonPeso}>Altura: {pokemon.height} Feet</Text> 
      </View>
      ):null}
       <View style={{flexDirection:"row", width:"80%", justifyContent:"space-around", marginTop:40}}>
       {pokemonId>1?(
        <Button title='Anterior' color="black" onPress={()=>{
          setPokemonId(pokemonId - 1)
       }}/>
       ):null}
       <Button title='Próximo'  color="black" onPress={()=>{
          setPokemonId(pokemonId + 1)
       }}/>
       </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'red',
    padding: 8,
  },
  pokemonBox: {
    width: 300,
    height:200, 
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection:'row',
    backgroundColor:"#1a1a1a",
    borderColor:"white",
    borderWidth: 20,
    borderRadius:5,
    borderBottomLeftRadius:30,
    marginTop:40,
  },
  pokemonNome: { 
    fontSize: 22, 
    color: 'white',
  },
  pokemonPeso: { 
    fontSize: 18,
    color: 'white',
   },
  pokemonImg: {
     width: 150,
    height: 150 
  },
  logo: { width: 200, height: 180 },
  pokemonText: { 
    alignItems:'center',
    justifyContent:'center',
    color: 'white',
    width: 300,
    marginTop:20,
    borderRadius:5,
    textAlign:"center",
    fontWeight:"500"
  }
  
});

export default App; 